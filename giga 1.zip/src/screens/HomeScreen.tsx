import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { RecordButton } from "../components/RecordButton";

interface HomeScreenProps {
  navigation: FrameNavigationProp<any, "home">;
}

export function HomeScreen({ navigation }: HomeScreenProps) {
  const [isRecording, setIsRecording] = React.useState(false);

  const handleStartRecording = () => {
    setIsRecording(true);
    // Implement recording logic
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    // Implement stop recording logic
  };

  return (
    <flexboxLayout style={styles.container}>
      <gridLayout rows="auto, *, auto" style={styles.content}>
        <stackLayout row={0} style={styles.header}>
          <label className="text-2xl font-bold">Gigadesk</label>
          <label className="text-gray-500">Your AI Voice Assistant</label>
        </stackLayout>

        <stackLayout row={1} style={styles.recordingSection}>
          <RecordButton
            isRecording={isRecording}
            onStartRecording={handleStartRecording}
            onStopRecording={handleStopRecording}
          />
        </stackLayout>

        <stackLayout row={2} style={styles.features}>
          <button className="feature-btn" onTap={() => navigation.navigate("Recordings")}>
            <label className="fas" text="" />
            <label>Recordings</label>
          </button>
          <button className="feature-btn" onTap={() => navigation.navigate("Transcripts")}>
            <label className="fas" text="" />
            <label>Transcripts</label>
          </button>
          <button className="feature-btn" onTap={() => navigation.navigate("Import")}>
            <label className="fas" text="" />
            <label>Import</label>
          </button>
        </stackLayout>
      </gridLayout>
    </flexboxLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    height: "100%",
    backgroundColor: "#FFFFFF",
  },
  content: {
    padding: 16,
  },
  header: {
    alignItems: "center",
    marginBottom: 32,
  },
  recordingSection: {
    alignItems: "center",
    justifyContent: "center",
  },
  features: {
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 16,
  },
});