import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { signIn, signUp } from "../services/auth";

export function AuthScreen({ navigation }) {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [isLogin, setIsLogin] = React.useState(true);

  const handleAuth = async () => {
    try {
      if (isLogin) {
        await signIn(email, password);
      } else {
        await signUp(email, password);
      }
      navigation.navigate("Home");
    } catch (error) {
      console.error("Auth error:", error);
    }
  };

  return (
    <flexboxLayout style={styles.container}>
      <stackLayout style={styles.form}>
        <label className="text-2xl font-bold mb-8">Welcome to Gigadesk</label>
        
        <textField
          hint="Email"
          keyboardType="email"
          text={email}
          onTextChange={(e) => setEmail(e.value)}
          style={styles.input}
        />
        
        <textField
          hint="Password"
          secure={true}
          text={password}
          onTextChange={(e) => setPassword(e.value)}
          style={styles.input}
        />
        
        <button
          className="bg-red-500 text-white p-4 rounded-lg"
          onTap={handleAuth}
          text={isLogin ? "Sign In" : "Sign Up"}
        />
        
        <button
          className="text-gray-600 mt-4"
          onTap={() => setIsLogin(!isLogin)}
          text={isLogin ? "Need an account? Sign Up" : "Have an account? Sign In"}
        />
      </stackLayout>
    </flexboxLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "white",
  },
  form: {
    width: "80%",
    alignItems: "center",
  },
  input: {
    width: "100%",
    height: 40,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    padding: 8,
    marginBottom: 16,
  },
});