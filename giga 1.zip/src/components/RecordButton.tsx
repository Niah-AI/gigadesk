import * as React from "react";
import { StyleSheet } from "react-nativescript";

export function RecordButton({ onStartRecording, onStopRecording, isRecording }) {
  return (
    <flexboxLayout style={styles.container}>
      <button
        className={`record-button ${isRecording ? 'recording' : ''}`}
        style={styles.recordButton}
        onTap={() => isRecording ? onStopRecording() : onStartRecording()}
      >
        <label className="fas" text={isRecording ? '' : ''} />
      </button>
      <label style={styles.recordingText}>
        {isRecording ? 'Tap to Stop' : 'Tap to Record'}
      </label>
    </flexboxLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  recordButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FF4B4B',
    color: 'white',
    fontSize: 30,
    textAlignment: 'center',
  },
  recordingText: {
    marginTop: 8,
    fontSize: 16,
    color: '#666',
  },
});