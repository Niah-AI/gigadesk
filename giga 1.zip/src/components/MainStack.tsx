import { BaseNavigationContainer } from '@react-navigation/core';
import * as React from "react";
import { stackNavigatorFactory } from "react-nativescript-navigation";
import { HomeScreen } from "../screens/HomeScreen";
import { AuthScreen } from "../screens/AuthScreen";

const StackNavigator = stackNavigatorFactory();

export const MainStack = () => (
  <BaseNavigationContainer>
    <StackNavigator.Navigator
      initialRouteName="Auth"
      screenOptions={{
        headerStyle: {
          backgroundColor: "#FF4B4B",
        },
        headerTintColor: "white",
        headerShown: true,
      }}
    >
      <StackNavigator.Screen
        name="Auth"
        component={AuthScreen}
        options={{ headerShown: false }}
      />
      <StackNavigator.Screen
        name="Home"
        component={HomeScreen}
        options={{
          title: "Gigadesk",
          headerLeft: () => null,
        }}
      />
    </StackNavigator.Navigator>
  </BaseNavigationContainer>
);