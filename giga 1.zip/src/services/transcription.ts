import { transcriptsCollection } from './firebase';

export const startTranscription = async (recordingId: string, language: string = 'en') => {
  await transcriptsCollection.doc(recordingId).set({
    status: 'processing',
    language,
    startTime: Date.now(),
  });
};

export const getTranscript = async (recordingId: string) => {
  const doc = await transcriptsCollection.doc(recordingId).get();
  return doc.data();
};