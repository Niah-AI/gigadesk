import { auth } from './firebase';

export const signIn = async (email: string, password: string) => {
  return await auth.signInWithEmailAndPassword(email, password);
};

export const signUp = async (email: string, password: string) => {
  return await auth.createUserWithEmailAndPassword(email, password);
};

export const signOut = async () => {
  return await auth.signOut();
};

export const getCurrentUser = () => {
  return auth.currentUser;
};