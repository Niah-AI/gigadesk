import { recordingsCollection, audioStorageRef, storage } from './firebase';
import type { Recording } from '../types';

export const startRecording = async (userId: string) => {
  const recording = {
    userId,
    startTime: Date.now(),
    status: 'recording',
    type: 'audio',
  };
  
  return await recordingsCollection.add(recording);
};

export const stopRecording = async (recordingId: string, audioFile: any) => {
  const fileName = `${recordingId}.m4a`;
  const reference = audioStorageRef.child(fileName);
  
  await reference.putFile(audioFile);
  const url = await reference.getDownloadURL();
  
  await recordingsCollection.doc(recordingId).update({
    status: 'processing',
    audioUrl: url,
    endTime: Date.now(),
  });
  
  return url;
};

export const getRecordings = async (userId: string) => {
  const snapshot = await recordingsCollection
    .where('userId', '==', userId)
    .orderBy('startTime', 'desc')
    .get();
    
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  })) as Recording[];
};