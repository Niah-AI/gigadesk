import { firebase } from '@nativescript/firebase-core';
import '@nativescript/firebase-auth';
import '@nativescript/firebase-firestore';
import '@nativescript/firebase-storage';

export const initializeFirebase = async () => {
  await firebase.initializeApp();
};

// Auth services
export const auth = firebase.auth();

// Firestore services
export const firestore = firebase.firestore();

// Storage services
export const storage = firebase.storage();

// Collections
export const recordingsCollection = firestore.collection('recordings');
export const transcriptsCollection = firestore.collection('transcripts');

// Storage references
export const audioStorageRef = storage.ref('audio');

export const uploadRecording = async (audioFile: any, userId: string) => {
  const fileName = `${userId}_${Date.now()}.m4a`;
  const reference = audioStorageRef.child(fileName);
  await reference.putFile(audioFile);
  return reference.getDownloadURL();
};

export const saveRecordingMetadata = async (data: any) => {
  return await recordingsCollection.add(data);
};