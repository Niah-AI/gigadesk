export interface Recording {
  id: string;
  title: string;
  duration: number;
  date: Date;
  transcript?: string;
  summary?: string;
  language?: string;
  type: 'audio' | 'call' | 'import';
  status: 'recording' | 'processing' | 'completed';
}

export interface Plan {
  name: 'Free' | 'Standard' | 'Pro';
  price: number;
  features: string[];
  recordingTime: number | 'unlimited';
}