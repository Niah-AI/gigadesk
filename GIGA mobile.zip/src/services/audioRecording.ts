import { TNSRecorder, TNSRecorderOptions } from '@nativescript/audio';
import { getCurrentUser } from './auth';
import { startRecording, stopRecording } from './recordings';
import { knownFolders } from '@nativescript/core';

class AudioRecordingService {
  private recorder: TNSRecorder;
  private currentRecordingId: string | null = null;
  private recordingPath: string;

  constructor() {
    this.recorder = new TNSRecorder();
    this.recordingPath = knownFolders.documents().path + '/recording.m4a';
  }

  async startNewRecording() {
    const user = getCurrentUser();
    if (!user) throw new Error('User must be authenticated to record');

    const options: TNSRecorderOptions = {
      filename: this.recordingPath,
      format: 'm4a',
      metering: true,
      sampleRate: 44100,
      channels: 1,
      bitRate: 128000,
    };

    try {
      const hasPermission = await this.recorder.requestRecordPermission();
      if (!hasPermission) throw new Error('Recording permission denied');

      await this.recorder.start(options);
      const recordingDoc = await startRecording(user.uid);
      this.currentRecordingId = recordingDoc.id;

      return this.currentRecordingId;
    } catch (error) {
      console.error('Failed to start recording:', error);
      throw error;
    }
  }

  async stopCurrentRecording() {
    if (!this.currentRecordingId) return;

    try {
      await this.recorder.stop();
      await stopRecording(this.currentRecordingId, this.recordingPath);
      this.currentRecordingId = null;
    } catch (error) {
      console.error('Failed to stop recording:', error);
      throw error;
    }
  }

  isRecording(): boolean {
    return this.recorder.isRecording();
  }

  dispose() {
    this.recorder.dispose();
  }
}

export const audioRecordingService = new AudioRecordingService();