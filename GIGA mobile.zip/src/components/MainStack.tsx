import { BaseNavigationContainer } from '@react-navigation/core';
import * as React from "react";
import { stackNavigatorFactory } from "react-nativescript-navigation";
import { HomeScreen } from "../screens/HomeScreen";
import { AuthScreen } from "../screens/AuthScreen";
import { RecordingsScreen } from "../screens/RecordingsScreen";
import { TranscriptDetailScreen } from "../screens/TranscriptDetailScreen";
import { SubscriptionScreen } from "../screens/SubscriptionScreen";

const StackNavigator = stackNavigatorFactory();

export const MainStack = () => (
  <BaseNavigationContainer>
    <StackNavigator.Navigator
      initialRouteName="Auth"
      screenOptions={{
        headerStyle: {
          backgroundColor: "#FF4B4B",
        },
        headerTintColor: "white",
        headerShown: true,
      }}
    >
      <StackNavigator.Screen
        name="Auth"
        component={AuthScreen}
        options={{ headerShown: false }}
      />
      <StackNavigator.Screen
        name="Home"
        component={HomeScreen}
        options={{
          title: "Gigadesk",
          headerLeft: () => null,
        }}
      />
      <StackNavigator.Screen
        name="Recordings"
        component={RecordingsScreen}
        options={{ title: "My Recordings" }}
      />
      <StackNavigator.Screen
        name="TranscriptDetail"
        component={TranscriptDetailScreen}
        options={{ title: "Transcript" }}
      />
      <StackNavigator.Screen
        name="Subscription"
        component={SubscriptionScreen}
        options={{ title: "Plans" }}
      />
    </StackNavigator.Navigator>
  </BaseNavigationContainer>
);