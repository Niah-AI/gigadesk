import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { audioRecordingService } from "../services/audioRecording";

export function RecordButton() {
  const [isRecording, setIsRecording] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    return () => {
      if (isRecording) {
        audioRecordingService.stopCurrentRecording();
      }
    };
  }, []);

  const handleStartRecording = async () => {
    try {
      setError(null);
      await audioRecordingService.startNewRecording();
      setIsRecording(true);
    } catch (err) {
      setError(err.message);
      console.error('Recording error:', err);
    }
  };

  const handleStopRecording = async () => {
    try {
      setError(null);
      await audioRecordingService.stopCurrentRecording();
      setIsRecording(false);
    } catch (err) {
      setError(err.message);
      console.error('Stop recording error:', err);
    }
  };

  return (
    <flexboxLayout style={styles.container}>
      <button
        className={`record-button ${isRecording ? 'recording' : ''}`}
        style={styles.recordButton}
        onTap={() => isRecording ? handleStopRecording() : handleStartRecording()}
      >
        <label className="fas" text={isRecording ? '' : ''} />
      </button>
      <label style={styles.recordingText}>
        {isRecording ? 'Tap to Stop' : 'Tap to Record'}
      </label>
      {error && (
        <label style={styles.errorText}>{error}</label>
      )}
    </flexboxLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  recordButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FF4B4B',
    color: 'white',
    fontSize: 30,
    textAlignment: 'center',
  },
  recordingText: {
    marginTop: 8,
    fontSize: 16,
    color: '#666',
  },
  errorText: {
    marginTop: 8,
    color: '#FF4B4B',
    fontSize: 14,
  },
});