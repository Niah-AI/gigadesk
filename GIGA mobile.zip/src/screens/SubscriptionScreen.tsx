import * as React from "react";
import { StyleSheet } from "react-nativescript";
import type { Plan } from "../types";

const plans: Plan[] = [
  {
    name: "Free",
    price: 0,
    features: [
      "30 minutes monthly recording",
      "Basic transcription",
      "Background recording",
    ],
    recordingTime: 30,
  },
  {
    name: "Standard",
    price: 12.99,
    features: [
      "5 hours monthly recording",
      "Advanced transcription",
      "Background recording",
      "Unlimited recording length",
    ],
    recordingTime: 300,
  },
  {
    name: "Pro",
    price: 21.99,
    features: [
      "Unlimited recording",
      "Priority transcription",
      "Custom summaries",
      "Web dashboard access",
    ],
    recordingTime: "unlimited",
  },
];

export function SubscriptionScreen() {
  return (
    <scrollView style={styles.container}>
      <stackLayout style={styles.content}>
        <label className="text-2xl font-bold mb-8 text-center">Choose Your Plan</label>
        
        {plans.map((plan) => (
          <stackLayout key={plan.name} style={styles.planCard}>
            <label className="text-xl font-bold">{plan.name}</label>
            <label className="text-2xl font-bold text-red-500">
              ${plan.price}{plan.price > 0 ? "/month" : ""}
            </label>
            
            <stackLayout style={styles.features}>
              {plan.features.map((feature) => (
                <label key={feature} className="text-gray-600">
                  ✓ {feature}
                </label>
              ))}
            </stackLayout>
            
            <button
              className="bg-red-500 text-white p-4 rounded-lg mt-4"
              text={plan.price > 0 ? "Subscribe Now" : "Get Started"}
            />
          </stackLayout>
        ))}
      </stackLayout>
    </scrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
  },
  content: {
    padding: 16,
  },
  planCard: {
    padding: 16,
    marginBottom: 16,
    borderRadius: 8,
    backgroundColor: "#f8f9fa",
    borderWidth: 1,
    borderColor: "#dee2e6",
  },
  features: {
    marginTop: 16,
    marginBottom: 16,
  },
});