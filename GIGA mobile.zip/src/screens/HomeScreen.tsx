import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { FrameNavigationProp } from "react-nativescript-navigation";
import { RecordButton } from "../components/RecordButton";
import { getCurrentUser } from "../services/auth";

interface HomeScreenProps {
  navigation: FrameNavigationProp<any, "home">;
}

export function HomeScreen({ navigation }: HomeScreenProps) {
  React.useEffect(() => {
    const user = getCurrentUser();
    if (!user) {
      navigation.navigate("Auth");
    }
  }, []);

  return (
    <flexboxLayout style={styles.container}>
      <gridLayout rows="auto, *, auto" style={styles.content}>
        <stackLayout row={0} style={styles.header}>
          <label className="text-2xl font-bold">Gigadesk</label>
          <label className="text-gray-500">Your AI Voice Assistant</label>
        </stackLayout>

        <stackLayout row={1} style={styles.recordingSection}>
          <RecordButton />
        </stackLayout>

        <stackLayout row={2} style={styles.features}>
          <button className="feature-btn" onTap={() => navigation.navigate("Recordings")}>
            <label className="fas" text="" />
            <label>Recordings</label>
          </button>
          <button className="feature-btn" onTap={() => navigation.navigate("TranscriptDetail")}>
            <label className="fas" text="" />
            <label>Transcripts</label>
          </button>
          <button className="feature-btn" onTap={() => navigation.navigate("Subscription")}>
            <label className="fas" text="" />
            <label>Plans</label>
          </button>
        </stackLayout>
      </gridLayout>
    </flexboxLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    height: "100%",
    backgroundColor: "#FFFFFF",
  },
  content: {
    padding: 16,
  },
  header: {
    alignItems: "center",
    marginBottom: 32,
  },
  recordingSection: {
    alignItems: "center",
    justifyContent: "center",
  },
  features: {
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 16,
  },
});