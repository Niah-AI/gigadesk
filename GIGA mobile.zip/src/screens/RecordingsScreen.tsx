import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { getRecordings } from "../services/recordings";
import { getCurrentUser } from "../services/auth";
import type { Recording } from "../types";

export function RecordingsScreen({ navigation }) {
  const [recordings, setRecordings] = React.useState<Recording[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const loadRecordings = async () => {
      const user = getCurrentUser();
      if (user) {
        const userRecordings = await getRecordings(user.uid);
        setRecordings(userRecordings);
      }
      setLoading(false);
    };

    loadRecordings();
  }, []);

  return (
    <flexboxLayout style={styles.container}>
      {loading ? (
        <activityIndicator busy={true} />
      ) : (
        <listView
          items={recordings}
          itemTemplateSelector={(item) => "recording"}
          templates={{
            recording: (item: Recording) => (
              <gridLayout columns="auto, *, auto" className="recording-item">
                <label col={0} className={`fas ${item.type === 'call' ? 'fa-phone' : 'fa-microphone'}`} />
                <stackLayout col={1} style={styles.recordingInfo}>
                  <label className="font-semibold">{item.title}</label>
                  <label className="text-gray-500">{new Date(item.date).toLocaleDateString()}</label>
                </stackLayout>
                <button 
                  col={2} 
                  className="text-blue-500"
                  text="View"
                  onTap={() => navigation.navigate("TranscriptDetail", { recordingId: item.id })}
                />
              </gridLayout>
            ),
          }}
        />
      )}
    </flexboxLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    height: "100%",
    backgroundColor: "white",
  },
  recordingInfo: {
    marginLeft: 12,
  },
});