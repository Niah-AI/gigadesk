import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { getTranscript } from "../services/transcription";

export function TranscriptDetailScreen({ route }) {
  const { recordingId } = route.params;
  const [transcript, setTranscript] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const loadTranscript = async () => {
      const data = await getTranscript(recordingId);
      setTranscript(data);
      setLoading(false);
    };

    loadTranscript();
  }, [recordingId]);

  return (
    <scrollView style={styles.container}>
      {loading ? (
        <activityIndicator busy={true} />
      ) : (
        <stackLayout style={styles.content}>
          <label className="text-xl font-bold mb-4">Transcript</label>
          <label className="transcript-text">{transcript?.text}</label>
          
          {transcript?.summary && (
            <>
              <label className="text-xl font-bold mt-8 mb-4">Summary</label>
              <label className="transcript-text">{transcript.summary}</label>
            </>
          )}
        </stackLayout>
      )}
    </scrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
  },
  content: {
    padding: 16,
  },
});